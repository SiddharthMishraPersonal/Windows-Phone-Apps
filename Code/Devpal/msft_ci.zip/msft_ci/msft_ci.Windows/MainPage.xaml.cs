﻿using Windows.UI.Xaml.Controls;

namespace msft_ci
{
    public sealed partial class MainPage : Page
    {
    }
}
