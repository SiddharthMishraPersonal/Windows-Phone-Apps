﻿using Windows.UI.Xaml.Controls;

namespace channel_connect
{
    public sealed partial class MainPage : Page
    {
    }
}
